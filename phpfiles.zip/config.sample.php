<?php

define('db_user', 'root');
define('db_password', '');
define('db_name', 'ptiwiki');
